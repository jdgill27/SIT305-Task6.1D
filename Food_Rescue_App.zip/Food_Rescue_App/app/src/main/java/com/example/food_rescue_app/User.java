package com.example.food_rescue_app;

public class User {
    public String fullName, email, phone, address;

    public User(){}

    public User(String fullName, String email, String phone, String address)
    {
        this.fullName = fullName;
        this.email = email;
        this.phone = phone;
        this.address = address;
    }
}
